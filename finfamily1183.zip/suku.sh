

java -Xms64m -Xmx800m -Djava.util.logging.config.file=properties/logging.properties -Dcom.sun.management.jmxremote -jar suku.jar $1
